TANUJ JHA PORTFOLIO — FINAL

This portfolio includes only the two live website links requested:
1. Lookmaxx: https://tjha5804-creator.github.io/lookmaxx-premium/
2. Vrindaji Sweets: https://tjha5804-creator.github.io/vrindaji-sweets-

Feel Hungry has been removed from the portfolio.
Open index.html in a browser to preview. To share as one online link, upload this folder to a static hosting service.
